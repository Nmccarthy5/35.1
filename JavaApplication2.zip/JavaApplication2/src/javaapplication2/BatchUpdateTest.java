/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import javax.swing.*;
import java.sql.*;

public class BatchUpdateTest {

    // Setup your DBConnectionPanel
    // ...

    public static void main(String[] args) {
        JButton connectButton = new JButton("Connect to Database");
        connectButton.addActionListener(e -> connectToDatabase());

        JFrame frame = new JFrame("Batch Update Test");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(connectButton);
        frame.setVisible(true);
    }

    public static void connectToDatabase() {
        // Since you've provided the MySQL details directly
        String url = "jdbc:mysql://localhost:3306/client";
        String user = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            long startTime = System.currentTimeMillis();
            insertWithoutBatch(conn);
            long endTime = System.currentTimeMillis();
            JOptionPane.showMessageDialog(null, "Without batch: " + (endTime - startTime) + "ms");

            startTime = System.currentTimeMillis();
            insertWithBatch(conn);
            endTime = System.currentTimeMillis();
            JOptionPane.showMessageDialog(null, "With batch: " + (endTime - startTime) + "ms");
        } catch (SQLException e) {
            // Display the error in a dialog box
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    public static void insertWithoutBatch(Connection conn) throws SQLException {
        String sql = "INSERT INTO Temp(num1, num2, num3) VALUES(?, ?, ?)";
        for (int i = 0; i < 1000; i++) {
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setDouble(1, Math.random());
                pstmt.setDouble(2, Math.random());
                pstmt.setDouble(3, Math.random());
                pstmt.executeUpdate();
            }
        }
    }

    public static void insertWithBatch(Connection conn) throws SQLException {
        String sql = "INSERT INTO Temp(num1, num2, num3) VALUES(?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (int i = 0; i < 1000; i++) {
                pstmt.setDouble(1, Math.random());
                pstmt.setDouble(2, Math.random());
                pstmt.setDouble(3, Math.random());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }
    }
} 